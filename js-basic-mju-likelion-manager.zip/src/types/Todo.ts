export type Todo = {
  id: string;
  content: string;
};

export type TodoItemNodeType = 'view' | 'update';
